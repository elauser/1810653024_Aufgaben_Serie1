package newpackage;

public class JavaClass {
    public static void main(String[] args) {
        System.out.println("FH Kufstein Tirol");
    }
}